# (c) HYBRID

import asyncio
import asyncpg
from hybrid import db, usersdb, DATABASE_URL

async def addpending(user_id: int, ch_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$set": {"pending": ch_id}})

async def rem_pending(user_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$unset": {"pending": 1}})

async def pending(user_id: int):
    user_data = await usersdb.find_one({"fsub_id": fsub_id})
    if user_data:
        return user_data.get("pending")
    else:
        return False

async def add_mainc(user_id: int, ch_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$set": {"main_channels": ch_id}})

async def remove_mainc(user_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$unset": {"main_channels": 1}})

async def add_fsub(user_id: int, fsub_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$set": {"fsub_id": fsub_id}})

async def add_flink(user_id: int, flink):
    await usersdb.update_one({"user_id": user_id}, {"$set": {"flink": flink}})

async def remove_flink(user_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$unset": {"flink": 1}})

async def fetch_flink(main_id: int):
    user_data = await usersdb.find_one({"main_channels": main_id})
    if user_data:
        return user_data.get("flink")
    else:
        return False

async def remove_fsub(user_id: int):
    await usersdb.update_one({"user_id": user_id}, {"$unset": {"fsub_id": 1}})

async def fetch_chan(user_id: int):
    user_data = await usersdb.find_one({"user_id": user_id})
    if user_data:
        return {"main_channels": user_data.get("main_channels"), "fsub_id": user_data.get("fsub_id")}
    else:
        return False

async def fetch_fsub(main_id: int):
    user_data = await usersdb.find_one({"main_channels": main_id})
    if user_data:
        return user_data.get("fsub_id")
    else:
        return False

async def fetch_main(fsub_id: int):
    user_data = await usersdb.find_one({"fsub_id": fsub_id})
    if user_data:
        return user_data.get("main_channels")
    else:
        return False

async def has_chan(user_id: int):
    user_data = await usersdb.find_one({"user_id": user_id})
    if user_data:
        return user_data.get("main_channels")
    else:
        return False

async def is_served_user(user_id: int) -> bool:
    user = await usersdb.find_one({"user_id": user_id})
    if not user:
        return False
    return True

async def add_served_user(user_id: int):
    is_served = await is_served_user(user_id)
    if is_served:
        return False
    await usersdb.insert_one({"user_id": user_id, "user_count": 0})
    return True

async def get_served_users() -> list:
    users_list = []
    async for user in usersdb.find({"user_id": {"$gt": 0}}):
        user_id = int(user["user_id"])
        users_list.append(user_id)
    return users_list

async def get_total_users_count():
    total_user_count = await usersdb.count_documents({})
    return total_user_count

async def save_string(value):
    conn = await asyncpg.connect(DATABASE_URL)
    try:
        await conn.execute('INSERT INTO strings (value) VALUES ($1)', value)
    except asyncpg.UniqueViolationError:
        # String already exists in the database
        pass
    finally:
        await conn.close()

async def check_string(value):
    conn = await asyncpg.connect(DATABASE_URL)
    try:
        result = await conn.fetchrow('SELECT 1 FROM strings WHERE value = $1', value)
        return bool(result)
    finally:
        await conn.close()

async def rem_words():
    conn = await asyncpg.connect(DATABASE_URL)
    await conn.execute('DELETE FROM strings')

async def remove_word(word):
    conn = await asyncpg.connect(DATABASE_URL)
    try:
        await conn.execute('DELETE FROM strings WHERE value = $1', word)
    finally:
        await conn.close()

