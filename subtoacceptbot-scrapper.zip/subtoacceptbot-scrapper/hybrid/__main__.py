# (c) HYBRID

import asyncio
import asyncpg
from hybrid import app

if __name__ == "__main__":
    app.run()
